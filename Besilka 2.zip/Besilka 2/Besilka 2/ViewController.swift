//
//  ViewController.swift
//  Besilka 2
//
//  Created by Tatjana Ocedova on 9/29/18.
//  Copyright © 2018 Tatjana Ocedova. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    
}

